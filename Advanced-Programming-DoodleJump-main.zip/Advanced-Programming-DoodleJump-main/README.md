# Advanced-Programming-DoodleJump
Doodle Jump game implemented with SFML for the Advanced Programming course at the University of Antwerp

[![CircleCI](https://circleci.com/gh/pabloDeputter/Advanced-Programming-DoodleJump/tree/main.svg?style=svg)](https://circleci.com/gh/pabloDeputter/Advanced-Programming-DoodleJump/tree/main)
