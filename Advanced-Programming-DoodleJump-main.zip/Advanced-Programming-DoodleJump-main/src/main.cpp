#include "Game.h"

using namespace std;

int main(int argc, char* argv[])
{
        Game game = Game(800, 1000);
        game.run();

        return 0;
}