//
// Created by Pablo Deputter on 29/11/2021.
//

#include "model/Background.h"

using namespace Model;